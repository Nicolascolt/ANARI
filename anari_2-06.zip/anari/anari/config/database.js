const config = {
  host: 'localhost',
  username: 'root',
  password: '230405',
  database: 'anari',
  dialect: 'mysql',
  define: {
    timestamps: false
}
  }
  
  module.exports = config;